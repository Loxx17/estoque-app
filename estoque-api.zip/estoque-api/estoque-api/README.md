# Sistema de Controle de Estoque

Aplicação distribuída desenvolvida em Java com Spring Boot para controle de estoque de pequenos comércios.

## Tecnologias

- Java 17
- Spring Boot 3.2
- Spring Data JPA
- Spring Security + JWT
- PostgreSQL
- Maven
- Lombok

## Pré-requisitos

- Java 17 instalado ([download](https://adoptium.net))
- PostgreSQL instalado e rodando
- IntelliJ IDEA (Community ou Ultimate)

## Configuração do banco de dados

1. Abra o PostgreSQL (via pgAdmin ou terminal)
2. Crie o banco de dados:
```sql
CREATE DATABASE estoque_db;
```
3. O script `src/main/resources/import.sql` será executado automaticamente na primeira inicialização

## Configuração da aplicação

Edite o arquivo `src/main/resources/application.yml` com suas credenciais do PostgreSQL:

```yaml
spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/estoque_db
    username: SEU_USUARIO
    password: SUA_SENHA
```

## Executando no IntelliJ

1. Abra o IntelliJ IDEA
2. `File → Open` e selecione a pasta do projeto
3. Aguarde o IntelliJ baixar as dependências Maven (pode demorar alguns minutos na primeira vez)
4. Abra `EstoqueApplication.java`
5. Clique no botão **Run** (triângulo verde) ao lado do método `main`
6. A API estará disponível em `http://localhost:8080`

## Endpoints da API

### Autenticação
| Método | Rota | Descrição |
|--------|------|-----------|
| POST | `/api/auth/login` | Fazer login e obter token JWT |
| POST | `/api/auth/register` | Cadastrar novo usuário |

### Produtos
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/produtos` | Listar todos os produtos ativos |
| GET | `/api/produtos/{id}` | Buscar produto por ID |
| GET | `/api/produtos/estoque-baixo` | Produtos abaixo do estoque mínimo |
| POST | `/api/produtos` | Cadastrar produto (ADMIN) |
| PUT | `/api/produtos/{id}` | Atualizar produto (ADMIN) |
| DELETE | `/api/produtos/{id}` | Inativar produto (ADMIN) |

### Movimentações
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/movimentacoes/produto/{id}` | Histórico de um produto |
| POST | `/api/movimentacoes` | Registrar entrada ou saída |

### Categorias e Fornecedores
| Método | Rota | Descrição |
|--------|------|-----------|
| GET/POST | `/api/categorias` | Listar e cadastrar |
| GET/PUT/DELETE | `/api/categorias/{id}` | Operações por ID |
| GET/POST | `/api/fornecedores` | Listar e cadastrar |
| GET/PUT/DELETE | `/api/fornecedores/{id}` | Operações por ID |

## Testando a API

Use o Postman ou Insomnia:

1. Faça login:
```json
POST /api/auth/login
{
  "email": "admin@estoque.com",
  "senha": "admin123"
}
```

2. Copie o token retornado e use no header das próximas requisições:
```
Authorization: Bearer <seu_token>
```

## Usuário padrão

- Email: `admin@estoque.com`
- Senha: `admin123`
- Role: `ADMIN`

## Estrutura do projeto

```
src/main/java/com/estoque/
├── EstoqueApplication.java
├── config/         # Segurança, JWT
├── controller/     # Endpoints REST
├── service/        # Regras de negócio
├── repository/     # Acesso ao banco
├── model/          # Entidades JPA
├── dto/            # Objetos de transferência
└── exception/      # Tratamento de erros
```

## Executando os testes

No IntelliJ: clique com botão direito na pasta `test` → `Run Tests`

Ou via terminal:
```bash
mvn test
```
