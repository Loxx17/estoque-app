package com.estoque.dto;

import com.estoque.model.Movimentacao.TipoMovimentacao;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;

public class DTOs {

    @Data
    public static class ProdutoDTO {
        @NotBlank(message = "Nome e obrigatorio")
        private String nome;
        private String descricao;
        @NotNull @DecimalMin("0.01")
        private BigDecimal preco;
        @Min(0) private Integer estoqueAtual = 0;
        @Min(0) private Integer estoqueMinimo = 5;
        private Long categoriaId;
        private Long fornecedorId;
    }

    @Data
    public static class MovimentacaoDTO {
        @NotNull private Long produtoId;
        @NotNull private TipoMovimentacao tipo;
        @Min(1)  private Integer quantidade;
        private String observacao;
    }

    @Data
    public static class LoginDTO {
        @NotBlank private String email;
        @NotBlank private String senha;
    }

    @Data
    public static class RegisterDTO {
        @NotBlank private String nome;
        @Email @NotBlank private String email;
        @NotBlank @Size(min = 6) private String senha;
    }

    @Data
    public static class TokenDTO {
        private String token;
        private String tipo = "Bearer";
        private String nome;
        private String role;
        public TokenDTO(String token, String nome, String role) {
            this.token = token;
            this.nome = nome;
            this.role = role;
        }
    }
}
