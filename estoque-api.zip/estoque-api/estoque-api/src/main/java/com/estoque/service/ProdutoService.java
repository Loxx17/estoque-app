package com.estoque.service;

import com.estoque.dto.DTOs.ProdutoDTO;
import com.estoque.model.Produto;
import com.estoque.repository.CategoriaRepository;
import com.estoque.repository.FornecedorRepository;
import com.estoque.repository.ProdutoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ProdutoService {

    private final ProdutoRepository produtoRepository;
    private final CategoriaRepository categoriaRepository;
    private final FornecedorRepository fornecedorRepository;

    public List<Produto> listarAtivos() {
        return produtoRepository.findByAtivoTrue();
    }

    public Produto buscarPorId(Long id) {
        return produtoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Produto nao encontrado: " + id));
    }

    public List<Produto> listarComEstoqueBaixo() {
        return produtoRepository.findAll().stream()
                .filter(p -> p.getAtivo() && p.getEstoqueAtual() <= p.getEstoqueMinimo())
                .toList();
    }

    @Transactional
    public Produto salvar(ProdutoDTO dto) {
        var produto = new Produto();
        preencherDados(produto, dto);
        return produtoRepository.save(produto);
    }

    @Transactional
    public Produto atualizar(Long id, ProdutoDTO dto) {
        var produto = buscarPorId(id);
        preencherDados(produto, dto);
        return produtoRepository.save(produto);
    }

    @Transactional
    public void inativar(Long id) {
        var produto = buscarPorId(id);
        produto.setAtivo(false);
        produtoRepository.save(produto);
    }

    private void preencherDados(Produto produto, ProdutoDTO dto) {
        produto.setNome(dto.getNome());
        produto.setDescricao(dto.getDescricao());
        produto.setPreco(dto.getPreco());
        produto.setEstoqueAtual(dto.getEstoqueAtual());
        produto.setEstoqueMinimo(dto.getEstoqueMinimo());

        if (dto.getCategoriaId() != null) {
            produto.setCategoria(categoriaRepository.findById(dto.getCategoriaId())
                    .orElseThrow(() -> new RuntimeException("Categoria nao encontrada")));
        }
        if (dto.getFornecedorId() != null) {
            produto.setFornecedor(fornecedorRepository.findById(dto.getFornecedorId())
                    .orElseThrow(() -> new RuntimeException("Fornecedor nao encontrado")));
        }
    }
}
