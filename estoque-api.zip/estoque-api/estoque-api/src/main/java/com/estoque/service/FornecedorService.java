package com.estoque.service;

import com.estoque.model.Fornecedor;
import com.estoque.repository.FornecedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FornecedorService {

    private final FornecedorRepository fornecedorRepository;

    public List<Fornecedor> listar() { return fornecedorRepository.findAll(); }

    public Fornecedor buscarPorId(Long id) {
        return fornecedorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Fornecedor nao encontrado: " + id));
    }

    public Fornecedor salvar(Fornecedor fornecedor) {
        if (fornecedor.getCnpj() != null && fornecedorRepository.existsByCnpj(fornecedor.getCnpj())) {
            throw new RuntimeException("CNPJ ja cadastrado");
        }
        return fornecedorRepository.save(fornecedor);
    }

    public Fornecedor atualizar(Long id, Fornecedor dados) {
        var f = buscarPorId(id);
        f.setNome(dados.getNome());
        f.setTelefone(dados.getTelefone());
        f.setEmail(dados.getEmail());
        return fornecedorRepository.save(f);
    }

    public void deletar(Long id) {
        buscarPorId(id);
        fornecedorRepository.deleteById(id);
    }
}
