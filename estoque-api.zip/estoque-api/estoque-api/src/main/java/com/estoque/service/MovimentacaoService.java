package com.estoque.service;

import com.estoque.dto.DTOs.MovimentacaoDTO;
import com.estoque.model.Movimentacao;
import com.estoque.model.Movimentacao.TipoMovimentacao;
import com.estoque.repository.MovimentacaoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MovimentacaoService {

    private final MovimentacaoRepository movimentacaoRepository;
    private final ProdutoService produtoService;

    public List<Movimentacao> listarPorProduto(Long produtoId) {
        return movimentacaoRepository.findByProdutoIdOrderByDataHoraDesc(produtoId);
    }

    @Transactional
    public Movimentacao registrar(MovimentacaoDTO dto) {
        var produto = produtoService.buscarPorId(dto.getProdutoId());

        if (dto.getTipo() == TipoMovimentacao.SAIDA) {
            if (produto.getEstoqueAtual() < dto.getQuantidade()) {
                throw new RuntimeException("Estoque insuficiente. Disponivel: " + produto.getEstoqueAtual());
            }
            produto.setEstoqueAtual(produto.getEstoqueAtual() - dto.getQuantidade());
        } else {
            produto.setEstoqueAtual(produto.getEstoqueAtual() + dto.getQuantidade());
        }

        var mov = new Movimentacao();
        mov.setProduto(produto);
        mov.setTipo(dto.getTipo());
        mov.setQuantidade(dto.getQuantidade());
        mov.setObservacao(dto.getObservacao());

        return movimentacaoRepository.save(mov);
    }
}
