package com.estoque.service;

import com.estoque.config.JwtService;
import com.estoque.dto.DTOs.*;
import com.estoque.model.Usuario;
import com.estoque.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public TokenDTO login(LoginDTO dto) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getSenha()));
        var usuario = usuarioRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new RuntimeException("Usuario nao encontrado"));
        var token = jwtService.generateToken(usuario);
        return new TokenDTO(token, usuario.getNome(), usuario.getRole().name());
    }

    public TokenDTO registrar(RegisterDTO dto) {
        if (usuarioRepository.existsByEmail(dto.getEmail())) {
            throw new RuntimeException("E-mail ja cadastrado");
        }
        var usuario = new Usuario();
        usuario.setNome(dto.getNome());
        usuario.setEmail(dto.getEmail());
        usuario.setSenha(passwordEncoder.encode(dto.getSenha()));
        usuario.setRole(Usuario.Role.OPERADOR);
        usuarioRepository.save(usuario);
        var token = jwtService.generateToken(usuario);
        return new TokenDTO(token, usuario.getNome(), usuario.getRole().name());
    }
}
