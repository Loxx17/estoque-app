package com.estoque.controller;

import com.estoque.dto.DTOs.*;
import com.estoque.model.*;
import com.estoque.service.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

// ===================== AUTH =====================
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
class AuthController {
    private final AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<TokenDTO> login(@Valid @RequestBody LoginDTO dto) {
        return ResponseEntity.ok(authService.login(dto));
    }

    @PostMapping("/register")
    public ResponseEntity<TokenDTO> register(@Valid @RequestBody RegisterDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(authService.registrar(dto));
    }
}

// ===================== PRODUTO =====================
@RestController
@RequestMapping("/api/produtos")
@RequiredArgsConstructor
class ProdutoController {
    private final ProdutoService produtoService;

    @GetMapping
    public List<Produto> listar() { return produtoService.listarAtivos(); }

    @GetMapping("/{id}")
    public Produto buscar(@PathVariable Long id) { return produtoService.buscarPorId(id); }

    @GetMapping("/estoque-baixo")
    public List<Produto> estoqueBaixo() { return produtoService.listarComEstoqueBaixo(); }

    @PostMapping
    public ResponseEntity<Produto> criar(@Valid @RequestBody ProdutoDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(produtoService.salvar(dto));
    }

    @PutMapping("/{id}")
    public Produto atualizar(@PathVariable Long id, @Valid @RequestBody ProdutoDTO dto) {
        return produtoService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> inativar(@PathVariable Long id) {
        produtoService.inativar(id);
        return ResponseEntity.noContent().build();
    }
}

// ===================== CATEGORIA =====================
@RestController
@RequestMapping("/api/categorias")
@RequiredArgsConstructor
class CategoriaController {
    private final CategoriaService categoriaService;

    @GetMapping  public List<Categoria> listar() { return categoriaService.listar(); }
    @GetMapping("/{id}") public Categoria buscar(@PathVariable Long id) { return categoriaService.buscarPorId(id); }

    @PostMapping
    public ResponseEntity<Categoria> criar(@Valid @RequestBody Categoria categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaService.salvar(categoria));
    }

    @PutMapping("/{id}")
    public Categoria atualizar(@PathVariable Long id, @RequestBody Categoria dados) {
        return categoriaService.atualizar(id, dados);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        categoriaService.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

// ===================== FORNECEDOR =====================
@RestController
@RequestMapping("/api/fornecedores")
@RequiredArgsConstructor
class FornecedorController {
    private final FornecedorService fornecedorService;

    @GetMapping  public List<Fornecedor> listar() { return fornecedorService.listar(); }
    @GetMapping("/{id}") public Fornecedor buscar(@PathVariable Long id) { return fornecedorService.buscarPorId(id); }

    @PostMapping
    public ResponseEntity<Fornecedor> criar(@Valid @RequestBody Fornecedor fornecedor) {
        return ResponseEntity.status(HttpStatus.CREATED).body(fornecedorService.salvar(fornecedor));
    }

    @PutMapping("/{id}")
    public Fornecedor atualizar(@PathVariable Long id, @RequestBody Fornecedor dados) {
        return fornecedorService.atualizar(id, dados);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        fornecedorService.deletar(id);
        return ResponseEntity.noContent().build();
    }
}

// ===================== MOVIMENTACAO =====================
@RestController
@RequestMapping("/api/movimentacoes")
@RequiredArgsConstructor
class MovimentacaoController {
    private final MovimentacaoService movimentacaoService;

    @GetMapping("/produto/{produtoId}")
    public List<Movimentacao> listarPorProduto(@PathVariable Long produtoId) {
        return movimentacaoService.listarPorProduto(produtoId);
    }

    @PostMapping
    public ResponseEntity<Movimentacao> registrar(@Valid @RequestBody MovimentacaoDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(movimentacaoService.registrar(dto));
    }
}
