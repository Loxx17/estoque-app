-- =============================================================
-- Script de criacao do banco de dados - Sistema de Estoque
-- =============================================================

CREATE TABLE IF NOT EXISTS categorias (
    id         BIGSERIAL PRIMARY KEY,
    nome       VARCHAR(100) NOT NULL UNIQUE,
    descricao  VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS fornecedores (
    id        BIGSERIAL PRIMARY KEY,
    nome      VARCHAR(150) NOT NULL,
    cnpj      VARCHAR(18)  UNIQUE,
    telefone  VARCHAR(20),
    email     VARCHAR(150)
);

CREATE TABLE IF NOT EXISTS produtos (
    id               BIGSERIAL PRIMARY KEY,
    nome             VARCHAR(150) NOT NULL,
    descricao        VARCHAR(255),
    preco            NUMERIC(10,2) NOT NULL,
    estoque_atual    INTEGER NOT NULL DEFAULT 0,
    estoque_minimo   INTEGER NOT NULL DEFAULT 5,
    ativo            BOOLEAN NOT NULL DEFAULT TRUE,
    categoria_id     BIGINT REFERENCES categorias(id),
    fornecedor_id    BIGINT REFERENCES fornecedores(id)
);

CREATE TABLE IF NOT EXISTS movimentacoes (
    id           BIGSERIAL PRIMARY KEY,
    produto_id   BIGINT NOT NULL REFERENCES produtos(id),
    tipo         VARCHAR(10) NOT NULL CHECK (tipo IN ('ENTRADA','SAIDA')),
    quantidade   INTEGER NOT NULL CHECK (quantidade > 0),
    data_hora    TIMESTAMP NOT NULL DEFAULT NOW(),
    observacao   VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS usuarios (
    id     BIGSERIAL PRIMARY KEY,
    nome   VARCHAR(150) NOT NULL,
    email  VARCHAR(150) NOT NULL UNIQUE,
    senha  VARCHAR(255) NOT NULL,
    role   VARCHAR(20)  NOT NULL DEFAULT 'OPERADOR'
);

-- Dados iniciais
INSERT INTO categorias (nome, descricao) VALUES
    ('Alimentos', 'Produtos alimenticios em geral'),
    ('Bebidas', 'Bebidas alcoolicas e nao alcoolicas'),
    ('Limpeza', 'Produtos de limpeza e higiene'),
    ('Eletronicos', 'Eletronicos e acessorios')
ON CONFLICT DO NOTHING;

INSERT INTO fornecedores (nome, cnpj, telefone, email) VALUES
    ('Distribuidora Central', '12.345.678/0001-99', '(11) 99999-0001', 'contato@central.com'),
    ('Atacado Norte', '98.765.432/0001-11', '(11) 99999-0002', 'vendas@atacadonorte.com')
ON CONFLICT DO NOTHING;

-- Senha: admin123 (BCrypt)
INSERT INTO usuarios (nome, email, senha, role) VALUES
    ('Administrador', 'admin@estoque.com',
     '$2a$10$7QJ8zW3Kv5Lp2Nm1Xr4Yu6Ts9Wb0Oc3Fd8Ge7Hj5Ik1Jl2Km3Ln4',
     'ADMIN')
ON CONFLICT DO NOTHING;
