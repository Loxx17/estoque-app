package com.estoque;

import com.estoque.model.Produto;
import com.estoque.repository.ProdutoRepository;
import com.estoque.service.ProdutoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProdutoServiceTest {

    @Mock ProdutoRepository produtoRepository;
    @Mock com.estoque.repository.CategoriaRepository categoriaRepository;
    @Mock com.estoque.repository.FornecedorRepository fornecedorRepository;

    @InjectMocks ProdutoService produtoService;

    @Test
    void deveLancarExcecaoQuandoProdutoNaoEncontrado() {
        when(produtoRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(RuntimeException.class, () -> produtoService.buscarPorId(99L));
    }

    @Test
    void deveRetornarProdutoQuandoEncontrado() {
        var produto = new Produto();
        produto.setId(1L);
        produto.setNome("Arroz 5kg");
        when(produtoRepository.findById(1L)).thenReturn(Optional.of(produto));
        var resultado = produtoService.buscarPorId(1L);
        assertEquals("Arroz 5kg", resultado.getNome());
    }
}
